<?php
session_start();
include_once 'db_con.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>SSL Wireless Exam Task</title>

        <!-- Bootstrap core CSS -->
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="css/full-slider.css" rel="stylesheet">

        <script type="text/javascript" src="http://code.jquery.com/jquery-1.4.3.min.js"></script>
        <script type="text/javascript" src="js/cricket.js"></script>
        
    </head>

    <body>

        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="#">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Home
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="shopping_cart.php">Shopping Cart</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="invoice.php">Basic Accounting</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <header>
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>

        </header>
        <div class="container">
            <br/>
            <br/>
            <br/>
            <div class="row ">
                <div class="col-md-12 text-right">
                    <a href="invoice_graph.php" target="_blank" class="btn btn-group-sm btn-info" > Graph View</a>
                </div>
            </div>
            <table class="table">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Type</th>
                    <th scope="col">Amount</th>
                    <th scope="col">Description</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $sql = "SELECT * FROM invoices";
                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0)
                {
                    $serial=0;
                    while($row = mysqli_fetch_assoc($result))
                    {
                        ++$serial;
                        //$return_value['data'][$row['head_type']][$row['id']]=$row;
                        ?>
                        <tr>
                            <td><?php echo $serial;?></td>
                            <td><?php echo $row['head_type'];?></td>
                            <td><?php echo $row['amount'];?></td>
                            <td><?php echo $row['description'];?></td>
                        </tr>
                    <?php
                    }
                }
                else
                {
                    ?>
                    <tr>
                        <td colspan="21"> Data Not Found.</td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>
            <?php
            if(isset($_SESSION['massage']) && $_SESSION['massage'])
            {
                ?>
                <div class="alert bg-info">
                    <p><?php echo $_SESSION['massage'];?></p>
                </div>
            <?php
            }
            ?>
            <!-- Page Content -->
            <form action="invoice_save.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="__data" value="invoice_data"/>
                <input type="hidden" name="__token" value="112233"/>
                <div class="form-group">
                    <label for="head_type">Type:</label>
                    <select class="form-control" name="head_type">
                        <option value="Income">Income</option>
                        <option value="Cost">Cost</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="amount">Amount:</label>
                    <input type="number" class="form-control" name="amount">
                </div>
                <div class="form-group">
                    <label for="amount">Description:</label>
                    <textarea class="form-control" name="description"></textarea>
                </div>
                <button type="submit" class="btn btn-default">Submit</button>
            </form>
        </div>


        <!-- Footer -->
        <footer class="py-0 bg-dark">

            <!-- /.container -->
        </footer>

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    </body>

</html>
<?php
$_SESSION['massage']='';
?>