<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>SSL Wireless Exam Task</title>

        <!-- Bootstrap core CSS -->
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="css/full-slider.css" rel="stylesheet">

        <script type="text/javascript" src="http://code.jquery.com/jquery-1.4.3.min.js"></script>
        <script type="text/javascript" src="js/cricket.js"></script>
        
    </head>

    <body>

        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="#">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Home
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="shopping_cart.php">Shopping Cart</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="invoice.php">Basic Accounting</a>
                        </li>
                        
                    </ul>
                </div>
            </div>
        </nav>

        <header>
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>

        </header>

        <!-- Page Content -->
        <section class="py-5">
            <div class="container">
                <br/>
                <h3>SSL Wireless PHP Task</h3>
                

                <table class="table table-bordered" width="100%">
                    <tr>
                        <th>Name</th>
                        <th>Total Runs</th>
                        <th>Total Balls</th>
                        <th>Runs</th>
                        <th>Out Categories</th>


                    </tr>
                    <tbody>
                        <tr>
                            <td>Player 1</td>
                            <td class="totalRuns"> <span id="total_run">0</span></td>
                            <td class="totalBalls"> <span id="total_over">0</span></td>
                            <td class="runs">
                                <button type="button" id="run1" class="btn p1 run_p1">1</button>
                                <button type="button" id="run2" class="btn p1 run_p1">2</button>
                                <button type="button" id="run3" class="btn p1 run_p1">3</button>
                                <button type="button" id="run4" class="btn p1 run_p1">4</button>
                                <button type="button" id="run5"  class="btn p1 run_p1">5</button>
                                <button type="button" id="run6"  class="btn p1 run_p1">6</button>
                            </td>
                            <td class="balls">
                                <button type="button" class="btn p1 out">Bowled</button>
                                <button type="button" class="btn p1 out">run out</button>
                                <button type="button" class="btn p1 out">caught</button>
                                <button type="button" class="btn p1 out">stumps</button>
                                <button type="button" class="btn p1">dot ball</button>
                            </td>

                        </tr>
                        <tr>
                            <td>Player 2</td>
                            <td class="totalRuns"> <span id="p2_total_run">0</span></td>
                            <td class="totalBalls"> <span id="p2_total_over">0</span></td>
                            <td class="runs">
                                <button type="button" id="p2_run1" class="btn p2 run_p2">1</button>
                                <button type="button" id="p2_run2" class="btn p2 run_p2">2</button>
                                <button type="button" id="p2_run3" class="btn p2 run_p2">3</button>
                                <button type="button" id="p2_run4" class="btn p2 run_p2">4</button>
                                <button type="button" id="p2_run5"  class="btn p2 run_p2">5</button>
                                <button type="button" id="p2_run6"  class="btn p2 run_p2">6</button>
                            </td>
                            <td class="balls">
                                <button type="button" class="btn p2 out">Bowled</button>
                                <button type="button" class="btn p2 out">run out</button>
                                <button type="button" class="btn p2 out">caught</button>
                                <button type="button" class="btn p2 out">stumps</button>
                                <button type="button" class="btn p2">dot ball</button>
                            </td>

                        </tr>
                    </tbody>
                </table>
            </div>
        </section>

        <!-- Footer -->
        <footer class="py-0 bg-dark">

            <!-- /.container -->
        </footer>

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    </body>

</html>
