<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "accounting_db";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn)
{
    echo "Connection failed: " . mysqli_connect_error();
    die();
}

if(isset($_POST['__data']) && $_POST['__data']=='invoice_data' && $_POST['__token']=='112233')
{
    $return_value=array();
    $sql = "INSERT INTO invoices (head_type, amount, description)VALUES ('".$_POST['head_type']."', '".$_POST['amount']."', '".$_POST['description']."')";
    if ($conn->query($sql) === TRUE)
    {
        $return_value['status']=true;
        $return_value['massage']="New record created successfully";
    }
    else
    {
        $return_value['status']=false;
        $return_value['massage']="Error: " . $sql . "<br>" . $conn->error;
    }
    header("Content-Type: application/json; charset=UTF-8");
    echo json_encode($return_value);
}
if(isset($_POST['__data']) && $_POST['__data']=='invoice_get_data' && $_POST['__token']=='223344')
{
    $return_value=array();
    $sql = "SELECT * FROM invoices";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
    {
        $return_value['status']=true;
        while($row = mysqli_fetch_assoc($result))
        {
            $return_value['data'][$row['head_type']][$row['id']]=$row;
        }
    }
    else
    {
        $return_value['status']=false;
        $return_value['massage']="Invoice data not found";
    }
    header("Content-Type: application/json; charset=UTF-8");
    echo json_encode($return_value);
}
?>