$(document).ready(function () {


    var $btn_p1 = $('.run_p1');
    $btn_p1.click(function () {
        var index = $btn_p1.index(this);
        $('#total_run').html(function (i, val) {
            return val * 1 + (index + 1);
        });
    });

    var over = 1;
    $('.p1').click(function () {
        $('#total_over').html(function (i, over) {
            var ball = over * 1 + 1;
            var balls;
            /*
             * calculate ball to over
             if (ball < 6) {
             balls = ball;
             } else {
             var over, rest_ball;
             over = parseInt(ball / 6);
             rest_ball = parseInt(ball % 6);
             //balls = "" + over + b;
             balls = a;
             //balls =over +"."+ b;
             }
             */
            return ball;
        });
    });

    //////////////////////////////////////////////////
    var $btn_p2 = $('.run_p2');
    $btn_p2.click(function () {
        var index = $btn_p2.index(this);
        $('#p2_total_run').html(function (i, val) {
            return val * 1 + (index + 1);
        });
    });


    var p2_over = 1;
    $('.p2').click(function () {
        $('#p2_total_over').html(function (p2_i, p2_over) {
            var p2_ball = p2_over * 1 + 1;
            return p2_ball;

        });
    });    
    
    //////////////////////////////////////////////////
    $('.out').click(function () {
        alert('The game is over.');        
        $(".btn").attr('disabled','disabled');
    });

});